from django.shortcuts import render
from .models import TataHub

# Create your views here.
def index(request):
    TataHub_list=TataHub.objects.all()
    return render(request,'index.html',{'TataHubs':TataHub_list})