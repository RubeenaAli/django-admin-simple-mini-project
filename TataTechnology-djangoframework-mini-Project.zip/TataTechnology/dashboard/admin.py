from unittest import result
from django.contrib import admin
from .models import TataHub

# Register your models here.

admin.site.register(TataHub)