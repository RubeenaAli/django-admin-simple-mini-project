from django import forms
from dashboard.models import TataHub



class TataHubForm(forms.ModelForm):

    class Meta:

        model=TataHub

        fields="__all__"