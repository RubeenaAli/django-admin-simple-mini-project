from django.db import models



# Create your models here.

class TataHub(models.Model):

    name=models.CharField(max_length=255)

    picture=models.ImageField()

    ceo=models.CharField(max_length=100)

    description=models.TextField()



    def __str__(self):

        result=self.name +" by"+self.ceo

        return result



    class Meta:

        db_table='TataHub'